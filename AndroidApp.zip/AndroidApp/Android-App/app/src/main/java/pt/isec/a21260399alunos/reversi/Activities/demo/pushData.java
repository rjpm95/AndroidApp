package pt.isec.a21260399alunos.reversi.Activities.demo;

import android.net.Uri;
import android.os.AsyncTask;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class pushData extends AsyncTask<Void, Void, Void> {
    String data="";
    HttpURLConnection connection = null;

    @Override
    protected Void doInBackground(Void... voids) {
        String host = "localhost:8080";
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("http")
                .authority("192.168.1.4:8080")
                .appendPath("cot")
                .appendPath("student")
                .appendPath("programmer")
                .appendPath("DMX")
                .appendPath("NjZQpKv6")
                .appendPath("MFXBar-A")
                .appendPath("Derby-2")
                .appendPath("50");
        builder.encodedAuthority(host);
        String myUrl = builder.build().toString();
        OutputStream out = null;
        //"http://192.168.1.4:8080/cot/student/programmer/DMX/NjZQpKv6/MFXBar-A/Derby-2?Ch1=50

        try {
            URL url = new URL("http://192.168.1.4:8080/cot/student/programmer/DMX/NjZQpKv6/MFXBar-A/Derby-2?Ch1=50");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            out = new BufferedOutputStream(urlConnection.getOutputStream());

            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"));
            writer.write(data);
            writer.flush();
            writer.close();
            out.close();

            urlConnection.connect();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


           /* URL url = new URL("http://192.168.1.4:8080/cot/student/program/json"); //Alterar o IPv4  - ir à linha de comandos e colocar ifconfig
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
                while(line != null){
                    line = bufferedReader.readLine();
                    data = data + line;
                }

                StringBuilder newData = new StringBuilder();
                StringBuilder newModel = new StringBuilder();
                List<String> models = new ArrayList<>();
                StringBuilder newFeature = new StringBuilder();
                List<String> features = new ArrayList<>();

                    for(int i=0; i < data.length();i++){
                        newData.append(data.charAt(i));

                        if(data.charAt(i) == '"' && data.charAt(i+1) == 'n' && data.charAt(i+2) == 'a' && data.charAt(i+3) == 'm' && data.charAt(i+4) == 'e' && data.charAt(i+5) == '"'){
                            for(int k=i+8; k < data.length(); k++){
                                if(data.charAt(k) == '"'){
                                    models.add(newModel.toString());
                                    newModel.setLength(0);
                                    break;
                                }
                                newModel.append(data.charAt(k));
                            }
                        }

                        if(data.charAt(i) == '{' ||  data.charAt(i) == ','){
                            newData.append("\n");
                        }
                    }

                    for(int i=0; i < data.length();i++){
                        newData.append(data.charAt(i));

                        if(data.charAt(i) == '"' && data.charAt(i+1) == 'f' && data.charAt(i+2) == 'e' && data.charAt(i+3) == 'a' && data.charAt(i+4) == 't' && data.charAt(i+5) == 'u' && data.charAt(i+6) == 'r' && data.charAt(i+7) == 'e'&& data.charAt(i+8) == '"'){
                            for(int k=i+11; k < data.length(); k++){
                                if(data.charAt(k) == '"'){
                                    features.add(newFeature.toString());
                                    newFeature.setLength(0);
                                    break;
                                }
                                newFeature.append(data.charAt(k));
                            }
                        }
                        if(data.charAt(i) == '{' ||  data.charAt(i) == ','){
                            newData.append("\n");
                        }
                    }*/


        //Log.d("MyApp", "-> " + features);
        //Log.d("MyApp", "-> " + models);
        //return models;
        //Log.d("MyApp","-> " + newData.toString());

        return null;
    }



}

package pt.isec.a21260399alunos.reversi.Activities.demo;

import android.os.Bundle;
import android.preference.PreferenceActivity;

public class AmbilWarnaDemoPreferenceActivity extends PreferenceActivity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
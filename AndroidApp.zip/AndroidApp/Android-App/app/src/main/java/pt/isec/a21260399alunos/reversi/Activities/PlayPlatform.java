package pt.isec.a21260399alunos.reversi.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import pt.isec.a21260399alunos.reversi.Activities.demo.ambilwarna.AmbilWarnaDialog;
import pt.isec.a21260399alunos.reversi.Activities.demo.pushData;
import pt.isec.a21260399alunos.reversi.R;

public class PlayPlatform extends AppCompatActivity {

    private ImageView img;
    private ViewGroup rootLayout;
    private int _xDelta;
    private int _yDelta;

    TextView text1;
    int color = 0xffffff00;

    Button sendAll;
    TextView textColor;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogar);
        rootLayout = (ViewGroup) findViewById(R.id.view_root);
        img = (ImageView) rootLayout.findViewById(R.id.imageView);
        //btt = (Button) rootLayout.findViewById(R.id.buttonView);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(650,165);
        img.setLayoutParams(layoutParams);
        //btt.setLayoutParams(layoutParams);
        ChoiceTouchListener ctl = new ChoiceTouchListener();

        img.setOnTouchListener(ctl);
        //btt.setOnTouchListener(ctl);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        sharedPreferences = getSharedPreferences("key_clr", Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();

        textColor=(TextView)findViewById(R.id.textColor);

        Spinner dropdown = findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{""});
        dropdown.setAdapter(adapter);

        Spinner dropdown2 = findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{""});
        dropdown2.setAdapter(adapter2);

        sendAll = (Button) findViewById(R.id.sendAll);

        sendAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pushData process = new pushData();
                process.execute();
                //Log.d("MyApp","-> " + models);
                //sendUDPPacket("1", String.format("%x", color));
            }
        });

        final View button1 = findViewById(R.id.chooseColor);
        text1 = (TextView) findViewById(R.id.textColor);
        displayColor();

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }

    private final class ChoiceTouchListener implements View.OnTouchListener{
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            final int X = (int) event.getRawX();
            final int Y = (int) event.getRawY();

            switch(event.getAction() & MotionEvent.ACTION_MASK){
                case MotionEvent.ACTION_DOWN:
                    RelativeLayout.LayoutParams lParams = (RelativeLayout.LayoutParams) v.getLayoutParams();
                    _xDelta = X - lParams.leftMargin;
                    _yDelta = Y - lParams.topMargin;
                    break;
                case MotionEvent.ACTION_UP:
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    break;
                case MotionEvent.ACTION_POINTER_UP:
                    break;
                case MotionEvent.ACTION_MOVE:
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) v.getLayoutParams();
                    layoutParams.leftMargin = X - _xDelta;
                    layoutParams.topMargin = Y - _yDelta;
                    layoutParams.rightMargin = -250;
                    layoutParams.bottomMargin = -250;
                    v.setLayoutParams(layoutParams);
                    break;
            }
            return true;
        }
    }

    void openDialog() {
        AmbilWarnaDialog dialog = new AmbilWarnaDialog(PlayPlatform.this, color, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                Toast.makeText(getApplicationContext(), "Color Chosen", Toast.LENGTH_SHORT).show();
                PlayPlatform.this.color = color;
                displayColor();
            }

            @Override
            public void onCancel(AmbilWarnaDialog dialog) {
                Toast.makeText(getApplicationContext(), "Canceled", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }

    void displayColor() {
        textColor.setText(String.format("%x", color));
    }

    public void back(View view) {
        finish();
    }
}

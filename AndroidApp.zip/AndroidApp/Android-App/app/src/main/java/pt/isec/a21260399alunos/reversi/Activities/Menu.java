package pt.isec.a21260399alunos.reversi.Activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import pt.isec.a21260399alunos.reversi.R;

public class Menu extends Activity {

    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_inicial);
    }

    public void onPlay(View view) {
        Intent intent = new Intent(this, PlayPlatform.class);
        startActivity(intent);
    }

    public void onCredits(View v) {
        // LayoutInflater é utilizado para inflar o layout numa view
        // Pegamos nessa instancia da classe
        LayoutInflater li = getLayoutInflater();

        // Inflamos o layout sobre.xml na view
        View view = li.inflate(R.layout.activity_creditos, null);
        // Definimos para o botão do layout um clickListener

        view.findViewById(R.id.backCreditos).setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Desfaz popUp
                dialog.dismiss();
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view);
        dialog = builder.create();
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
    }
}

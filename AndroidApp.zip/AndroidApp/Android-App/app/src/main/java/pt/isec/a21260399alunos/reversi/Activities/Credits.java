package pt.isec.a21260399alunos.reversi.Activities;

import android.app.Activity;
import android.os.Bundle;

import pt.isec.a21260399alunos.reversi.R;

public class Credits extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creditos);
    }
}
